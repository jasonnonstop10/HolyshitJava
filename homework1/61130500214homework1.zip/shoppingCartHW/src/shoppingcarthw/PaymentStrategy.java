/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shoppingcarthw;

/**
 *
 * @author Lenovo
 */
//PaymentStrategy interface (pay method) 
public interface PaymentStrategy {
    void pay(int total);
    
}
